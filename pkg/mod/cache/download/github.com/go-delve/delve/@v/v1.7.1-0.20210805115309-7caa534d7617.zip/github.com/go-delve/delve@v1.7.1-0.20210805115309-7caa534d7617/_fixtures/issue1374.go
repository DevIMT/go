package main

import "fmt"

func main() {
	i := getNum()
	fmt.Println(i)
}

func getNum() int {
	return 0
}
